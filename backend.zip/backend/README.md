# Khaotic Calls — Backend

Node.js + TypeScript + Fastify. Responsável só pelo que o Supabase
sozinho não resolve com segurança: gerar tokens temporários do
LiveKit e gerenciar a permissão de admin (independente da posse da
badge "Founder").

## Rotas

```
GET    /health

POST   /calls                    cria uma sala
GET    /calls/:code              busca sala pelo código (KHAO-XXXXX)
POST   /calls/:code/join         valida e entra numa sala
DELETE /calls/:id                encerra sala (owner ou admin)
POST   /calls/:id/token          gera token temporário do LiveKit

GET    /users/me/badges          lista badges do usuário logado
POST   /admin/badges/assign      atribui badge (admin only)
DELETE /admin/badges/:userId     remove badge (admin only)
```

Todas as rotas exigem `Authorization: Bearer <supabase_access_token>`.
As rotas `/admin/*` exigem além disso que o `user_id` esteja na
tabela `admins` do banco.

## Setup

```bash
cp .env.example .env
# preencha SUPABASE_SERVICE_ROLE_KEY, LIVEKIT_API_KEY, LIVEKIT_API_SECRET, LIVEKIT_WS_URL

npm install
npm run dev
```

Servidor sobe em `http://localhost:3333` por padrão.

## Onde pegar cada chave

- **SUPABASE_SERVICE_ROLE_KEY**: Supabase Dashboard → Project Settings
  → API → `service_role` `secret`. **NUNCA** vai no app Flutter — só
  aqui no backend.
- **LIVEKIT_API_KEY / SECRET / WS_URL**: crie um projeto grátis em
  https://cloud.livekit.io, aba Settings → Keys.

## Segurança

- Todo endpoint valida o JWT do Supabase antes de fazer qualquer
  coisa (`src/auth/require-auth.ts`) — nunca confia em um `user_id`
  vindo do corpo da requisição.
- A permissão de admin/Founder é checada consultando a tabela
  `admins` a cada request administrativa — nunca fica em cache no
  client, nunca é assumida a partir de uma flag do app.
- O `service_role` do Supabase só existe neste backend. O app Flutter
  só recebe a `anon key` (pública, segura por design via RLS).
