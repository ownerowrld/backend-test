import Fastify, { type FastifyError } from 'fastify';
import cors from '@fastify/cors';
import { env } from './env.js';
import { callsRoutes } from './calls/routes.js';
import { badgesRoutes } from './badges/routes.js';
import { friendsRoutes } from './friends/routes.js';
import { invitesRoutes } from './invites/routes.js';

const app = Fastify({
  logger: {
    level: 'info',
    transport: { target: 'pino-pretty' },
  },
});

await app.register(cors, {
  origin: env.CORS_ORIGIN === '*' ? true : env.CORS_ORIGIN.split(','),
});

app.get('/health', async () => ({ status: 'ok' }));

await app.register(callsRoutes);
await app.register(badgesRoutes);
await app.register(friendsRoutes);
await app.register(invitesRoutes);

app.setErrorHandler((err: FastifyError, request, reply) => {
  request.log.error(err);
  reply.code(err.statusCode ?? 500).send({ error: err.message ?? 'Erro interno.' });
});

const port = Number(env.PORT);
app.listen({ port, host: '0.0.0.0' }).then(() => {
  console.log(`🩸 Khaotic Calls backend rodando na porta ${port}`);
});
