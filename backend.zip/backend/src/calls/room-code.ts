import { customAlphabet } from 'nanoid';

// Alfabeto sem caracteres ambíguos (sem 0/O, 1/I/L) pra facilitar
// digitar/ler o código em voz alta.
const alphabet = '23456789ABCDEFGHJKMNPQRSTUVWXYZ';
const generate = customAlphabet(alphabet, 5);

/// Gera um código de sala no formato "KHAO-8F4KD".
export function generateRoomCode(): string {
  return `KHAO-${generate()}`;
}
