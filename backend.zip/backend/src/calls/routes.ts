import type { FastifyInstance } from 'fastify';
import { AccessToken } from 'livekit-server-sdk';
import { env } from '../env.js';
import { requireAuth } from '../auth/require-auth.js';
import { supabaseAdmin } from '../plugins/supabase.js';
import { generateRoomCode } from './room-code.js';
import { createRoomSchema } from './schemas.js';

export async function callsRoutes(app: FastifyInstance) {
  // Todas as rotas de calls exigem autenticação.
  app.addHook('preHandler', requireAuth);

  // -----------------------------------------------------------
  // POST /calls — cria uma nova sala
  // -----------------------------------------------------------
  app.post('/calls', async (request, reply) => {
    const parsed = createRoomSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: 'Dados inválidos.', details: parsed.error.format() });
    }

    const { name, max_participants, is_private } = parsed.data;

    // Tenta gerar um código único (retry em caso de colisão rara).
    let code = generateRoomCode();
    for (let attempt = 0; attempt < 5; attempt++) {
      const { data: existing } = await supabaseAdmin
        .from('rooms')
        .select('id')
        .eq('code', code)
        .maybeSingle();
      if (!existing) break;
      code = generateRoomCode();
    }

    const { data: room, error } = await supabaseAdmin
      .from('rooms')
      .insert({
        code,
        name,
        owner_id: request.userId,
        max_participants,
        is_private,
      })
      .select()
      .single();

    if (error) {
      request.log.error(error);
      return reply.code(500).send({ error: 'Não foi possível criar a sala.' });
    }

    return reply.code(201).send(room);
  });

  // -----------------------------------------------------------
  // GET /calls/:code — busca uma sala pelo código (KHAO-XXXXX) ou,
  // se o parâmetro for um UUID, pelo id diretamente (usado pela
  // tela de call pra exibir o código no botão de convidar).
  // -----------------------------------------------------------
  const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

  app.get<{ Params: { code: string } }>('/calls/:code', async (request, reply) => {
    const { code } = request.params;
    const isUuid = uuidPattern.test(code);

    const query = supabaseAdmin.from('rooms').select();
    const { data: room, error } = isUuid
      ? await query.eq('id', code).maybeSingle()
      : await query.eq('code', code.toUpperCase()).maybeSingle();

    if (error || !room) {
      return reply.code(404).send({ error: 'Sala não encontrada.' });
    }

    return reply.send(room);
  });

  // -----------------------------------------------------------
  // POST /calls/:code/join — entra numa sala (valida limite/privacidade)
  // -----------------------------------------------------------
  app.post<{ Params: { code: string } }>('/calls/:code/join', async (request, reply) => {
    const { code } = request.params;

    const { data: room, error } = await supabaseAdmin
      .from('rooms')
      .select()
      .eq('code', code.toUpperCase())
      .maybeSingle();

    if (error || !room) {
      return reply.code(404).send({ error: 'Sala não encontrada.' });
    }

    if (room.expires_at && new Date(room.expires_at) < new Date()) {
      return reply.code(410).send({ error: 'Essa sala expirou.' });
    }

    // Checa quantos participantes já estão conectados no LiveKit
    // antes de deixar entrar (evita estourar max_participants).
    const roomService = getRoomServiceClient();
    try {
      const participants = await roomService.listParticipants(room.id);
      if (participants.length >= room.max_participants) {
        return reply.code(409).send({ error: 'Sala cheia.' });
      }
    } catch {
      // Sala ainda não existe no LiveKit (ninguém entrou ainda) — ok, deixa passar.
    }

    return reply.send(room);
  });

  // -----------------------------------------------------------
  // DELETE /calls/:id — encerra uma sala (só owner ou admin)
  // -----------------------------------------------------------
  app.delete<{ Params: { id: string } }>('/calls/:id', async (request, reply) => {
    const { id } = request.params;

    const { data: room } = await supabaseAdmin
      .from('rooms')
      .select('owner_id')
      .eq('id', id)
      .maybeSingle();

    if (!room) {
      return reply.code(404).send({ error: 'Sala não encontrada.' });
    }

    const isOwner = room.owner_id === request.userId;
    const isAdmin = await checkIsAdmin(request.userId!);

    if (!isOwner && !isAdmin) {
      return reply.code(403).send({ error: 'Você não tem permissão para encerrar essa sala.' });
    }

    await supabaseAdmin.from('rooms').delete().eq('id', id);
    return reply.code(204).send();
  });

  // -----------------------------------------------------------
  // POST /calls/:id/token — gera o token temporário do LiveKit
  // -----------------------------------------------------------
  app.post<{ Params: { id: string } }>('/calls/:id/token', async (request, reply) => {
    const { id: roomId } = request.params;

    const { data: room, error } = await supabaseAdmin
      .from('rooms')
      .select()
      .eq('id', roomId)
      .maybeSingle();

    if (error || !room) {
      return reply.code(404).send({ error: 'Sala não encontrada.' });
    }

    // Busca o profile pra usar como identidade visível na call.
    const { data: profile } = await supabaseAdmin
      .from('profiles')
      .select('username, display_name')
      .eq('user_id', request.userId)
      .single();

    const token = new AccessToken(env.LIVEKIT_API_KEY, env.LIVEKIT_API_SECRET, {
      identity: request.userId!,
      name: profile?.display_name ?? profile?.username ?? 'Usuário',
      ttl: '4h',
    });

    // Usa o próprio id da sala (uuid) como nome da sala no LiveKit —
    // estável e único, independente do "code" (que é só pra humanos).
    token.addGrant({
      room: room.id,
      roomJoin: true,
      canPublish: true,
      canSubscribe: true,
      canPublishData: true,
    });

    return reply.send({
      token: await token.toJwt(),
      ws_url: env.LIVEKIT_WS_URL,
      room_name: room.id,
    });
  });
}

/// Verifica se o usuário está na tabela `admins` — a permissão de
/// gerenciar salas/badges é SEMPRE checada aqui, nunca no client.
async function checkIsAdmin(userId: string): Promise<boolean> {
  const { data } = await supabaseAdmin
    .from('admins')
    .select('user_id')
    .eq('user_id', userId)
    .maybeSingle();
  return !!data;
}

// Import tardio pra evitar ciclo — RoomServiceClient vem do mesmo pacote.
import { RoomServiceClient } from 'livekit-server-sdk';

function getRoomServiceClient() {
  const httpUrl = env.LIVEKIT_WS_URL.replace('wss://', 'https://').replace('ws://', 'http://');
  return new RoomServiceClient(httpUrl, env.LIVEKIT_API_KEY, env.LIVEKIT_API_SECRET);
}
