import { z } from 'zod';

export const createRoomSchema = z.object({
  name: z.string().trim().min(1).max(60),
  max_participants: z.number().int().min(2).max(50).default(10),
  is_private: z.boolean().default(false),
});

export type CreateRoomInput = z.infer<typeof createRoomSchema>;
