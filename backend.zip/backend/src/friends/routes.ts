import type { FastifyInstance } from 'fastify';
import { requireAuth } from '../auth/require-auth.js';
import { supabaseAdmin } from '../plugins/supabase.js';
import { sendFriendRequestSchema } from './schemas.js';

/// Dado um par de IDs, retorna [menor, maior] — a tabela friendships
/// exige que user_a_id seja sempre o menor UUID, pra nunca existir
/// duas linhas representando o mesmo par em ordens diferentes.
function orderedPair(idA: string, idB: string): [string, string] {
  return idA < idB ? [idA, idB] : [idB, idA];
}

export async function friendsRoutes(app: FastifyInstance) {
  app.addHook('preHandler', requireAuth);

  // -----------------------------------------------------------
  // GET /friends — lista amizades aceitas + solicitações pendentes
  // (tanto enviadas quanto recebidas), já com o profile da outra pessoa.
  // -----------------------------------------------------------
  app.get('/friends', async (request, reply) => {
    const userId = request.userId!;

    const { data: friendships, error } = await supabaseAdmin
      .from('friendships')
      .select('*')
      .or(`user_a_id.eq.${userId},user_b_id.eq.${userId}`)
      .order('created_at', { ascending: false });

    if (error) {
      request.log.error(error);
      return reply.code(500).send({ error: 'Erro ao buscar amigos.' });
    }

    if (!friendships || friendships.length === 0) {
      return reply.send([]);
    }

    // friendships referencia auth.users, não public.profiles
    // diretamente, então não dá pra fazer join automático — busca
    // os profiles das "outras pessoas" numa segunda query.
    const otherUserIds = friendships.map((row) =>
      row.user_a_id === userId ? row.user_b_id : row.user_a_id,
    );

    const { data: profiles, error: profilesError } = await supabaseAdmin
      .from('profiles')
      .select('*')
      .in('user_id', otherUserIds);

    if (profilesError) {
      request.log.error(profilesError);
      return reply.code(500).send({ error: 'Erro ao buscar perfis dos amigos.' });
    }

    const profileByUserId = new Map((profiles ?? []).map((p) => [p.user_id, p]));

    const normalized = friendships.map((row) => {
      const isUserA = row.user_a_id === userId;
      const otherUserId = isUserA ? row.user_b_id : row.user_a_id;
      return {
        id: row.id,
        status: row.status,
        requested_by: row.requested_by,
        is_incoming: row.status === 'pending' && row.requested_by !== userId,
        created_at: row.created_at,
        responded_at: row.responded_at,
        friend: profileByUserId.get(otherUserId) ?? null,
      };
    });

    return reply.send(normalized);
  });

  // -----------------------------------------------------------
  // POST /friends/request — envia solicitação de amizade por username
  // -----------------------------------------------------------
  app.post('/friends/request', async (request, reply) => {
    const parsed = sendFriendRequestSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: 'Dados inválidos.', details: parsed.error.format() });
    }

    const userId = request.userId!;
    const { username } = parsed.data;

    const { data: targetProfile } = await supabaseAdmin
      .from('profiles')
      .select('user_id')
      .eq('username', username)
      .maybeSingle();

    if (!targetProfile) {
      return reply.code(404).send({ error: 'Usuário não encontrado.' });
    }
    if (targetProfile.user_id === userId) {
      return reply.code(400).send({ error: 'Você não pode adicionar a si mesmo.' });
    }

    const [userAId, userBId] = orderedPair(userId, targetProfile.user_id);

    const { data: existing } = await supabaseAdmin
      .from('friendships')
      .select('id, status')
      .eq('user_a_id', userAId)
      .eq('user_b_id', userBId)
      .maybeSingle();

    if (existing) {
      return reply.code(409).send({
        error: existing.status === 'accepted'
          ? 'Vocês já são amigos.'
          : 'Já existe uma solicitação pendente com essa pessoa.',
      });
    }

    const { data: friendship, error } = await supabaseAdmin
      .from('friendships')
      .insert({
        user_a_id: userAId,
        user_b_id: userBId,
        requested_by: userId,
        status: 'pending',
      })
      .select()
      .single();

    if (error) {
      request.log.error(error);
      return reply.code(500).send({ error: 'Não foi possível enviar a solicitação.' });
    }

    return reply.code(201).send(friendship);
  });

  // -----------------------------------------------------------
  // POST /friends/:id/accept — aceita uma solicitação recebida
  // -----------------------------------------------------------
  app.post<{ Params: { id: string } }>('/friends/:id/accept', async (request, reply) => {
    const userId = request.userId!;
    const { id } = request.params;

    const { data: friendship } = await supabaseAdmin
      .from('friendships')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (!friendship) return reply.code(404).send({ error: 'Solicitação não encontrada.' });

    const isParty = friendship.user_a_id === userId || friendship.user_b_id === userId;
    if (!isParty) return reply.code(403).send({ error: 'Sem permissão.' });

    // Só quem RECEBEU a solicitação pode aceitar (não quem enviou).
    if (friendship.requested_by === userId) {
      return reply.code(403).send({ error: 'Você não pode aceitar sua própria solicitação.' });
    }

    const { data: updated, error } = await supabaseAdmin
      .from('friendships')
      .update({ status: 'accepted', responded_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();

    if (error) return reply.code(500).send({ error: 'Erro ao aceitar solicitação.' });
    return reply.send(updated);
  });

  // -----------------------------------------------------------
  // DELETE /friends/:id — recusa solicitação, cancela envio, ou
  // desfaz amizade (mesma ação para os três casos).
  // -----------------------------------------------------------
  app.delete<{ Params: { id: string } }>('/friends/:id', async (request, reply) => {
    const userId = request.userId!;
    const { id } = request.params;

    const { data: friendship } = await supabaseAdmin
      .from('friendships')
      .select('user_a_id, user_b_id')
      .eq('id', id)
      .maybeSingle();

    if (!friendship) return reply.code(404).send({ error: 'Não encontrado.' });

    const isParty = friendship.user_a_id === userId || friendship.user_b_id === userId;
    if (!isParty) return reply.code(403).send({ error: 'Sem permissão.' });

    await supabaseAdmin.from('friendships').delete().eq('id', id);
    return reply.code(204).send();
  });
}
