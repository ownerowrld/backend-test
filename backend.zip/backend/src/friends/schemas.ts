import { z } from 'zod';

export const sendFriendRequestSchema = z.object({
  username: z.string().trim().min(1),
});

export type SendFriendRequestInput = z.infer<typeof sendFriendRequestSchema>;
