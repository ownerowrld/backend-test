import { z } from 'zod';

export const createInviteSchema = z.object({
  room_id: z.string().uuid(),
  invited_user_id: z.string().uuid(),
});

export type CreateInviteInput = z.infer<typeof createInviteSchema>;
