import type { FastifyInstance } from 'fastify';
import { requireAuth } from '../auth/require-auth.js';
import { supabaseAdmin } from '../plugins/supabase.js';
import { createInviteSchema } from './schemas.js';

export async function invitesRoutes(app: FastifyInstance) {
  app.addHook('preHandler', requireAuth);

  // -----------------------------------------------------------
  // POST /invites — convida um amigo pra uma sala já existente.
  // Só quem é amigo (amizade aceita) pode ser convidado — o
  // backend checa isso, não confia no client.
  // -----------------------------------------------------------
  app.post('/invites', async (request, reply) => {
    const parsed = createInviteSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: 'Dados inválidos.', details: parsed.error.format() });
    }

    const userId = request.userId!;
    const { room_id, invited_user_id } = parsed.data;

    if (invited_user_id === userId) {
      return reply.code(400).send({ error: 'Você não pode se convidar.' });
    }

    // Confirma que a sala existe.
    const { data: room } = await supabaseAdmin
      .from('rooms')
      .select('id')
      .eq('id', room_id)
      .maybeSingle();
    if (!room) return reply.code(404).send({ error: 'Sala não encontrada.' });

    // Confirma que são amigos de verdade (amizade aceita).
    const [userA, userB] = userId < invited_user_id
      ? [userId, invited_user_id]
      : [invited_user_id, userId];

    const { data: friendship } = await supabaseAdmin
      .from('friendships')
      .select('status')
      .eq('user_a_id', userA)
      .eq('user_b_id', userB)
      .maybeSingle();

    if (!friendship || friendship.status !== 'accepted') {
      return reply.code(403).send({ error: 'Vocês precisam ser amigos pra convidar.' });
    }

    const { data: invite, error } = await supabaseAdmin
      .from('call_invites')
      .insert({
        room_id,
        invited_by: userId,
        invited_user_id,
      })
      .select()
      .single();

    if (error) {
      request.log.error(error);
      return reply.code(500).send({ error: 'Não foi possível enviar o convite.' });
    }

    return reply.code(201).send(invite);
  });

  // -----------------------------------------------------------
  // GET /invites — lista convites recebidos (não lidos primeiro),
  // já com o profile de quem convidou e os dados da sala.
  // -----------------------------------------------------------
  app.get('/invites', async (request, reply) => {
    const userId = request.userId!;

    const { data: invites, error } = await supabaseAdmin
      .from('call_invites')
      .select('*')
      .eq('invited_user_id', userId)
      .order('created_at', { ascending: false })
      .limit(50);

    if (error) {
      request.log.error(error);
      return reply.code(500).send({ error: 'Erro ao buscar convites.' });
    }

    if (!invites || invites.length === 0) {
      return reply.send([]);
    }

    const inviterIds = [...new Set(invites.map((i) => i.invited_by))];
    const roomIds = [...new Set(invites.map((i) => i.room_id))];

    const [{ data: profiles }, { data: rooms }] = await Promise.all([
      supabaseAdmin.from('profiles').select('*').in('user_id', inviterIds),
      supabaseAdmin.from('rooms').select('*').in('id', roomIds),
    ]);

    const profileByUserId = new Map((profiles ?? []).map((p) => [p.user_id, p]));
    const roomById = new Map((rooms ?? []).map((r) => [r.id, r]));

    const normalized = invites.map((invite) => ({
      id: invite.id,
      is_read: invite.is_read,
      created_at: invite.created_at,
      invited_by_profile: profileByUserId.get(invite.invited_by) ?? null,
      room: roomById.get(invite.room_id) ?? null,
    }));

    return reply.send(normalized);
  });

  // -----------------------------------------------------------
  // POST /invites/:id/read — marca um convite como lido
  // -----------------------------------------------------------
  app.post<{ Params: { id: string } }>('/invites/:id/read', async (request, reply) => {
    const userId = request.userId!;
    const { id } = request.params;

    const { data: invite } = await supabaseAdmin
      .from('call_invites')
      .select('invited_user_id')
      .eq('id', id)
      .maybeSingle();

    if (!invite) return reply.code(404).send({ error: 'Convite não encontrado.' });
    if (invite.invited_user_id !== userId) {
      return reply.code(403).send({ error: 'Sem permissão.' });
    }

    await supabaseAdmin.from('call_invites').update({ is_read: true }).eq('id', id);
    return reply.code(204).send();
  });
}
