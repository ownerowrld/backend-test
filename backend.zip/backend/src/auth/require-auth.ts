import type { FastifyReply, FastifyRequest } from 'fastify';
import { supabaseAdmin } from '../plugins/supabase.js';

/// Estende o tipo do request pra carregar o usuário autenticado.
declare module 'fastify' {
  interface FastifyRequest {
    userId?: string;
  }
}

/// Middleware que valida o token JWT do Supabase enviado no header
/// `Authorization: Bearer <token>`.
///
/// Isso é o que garante que o backend NUNCA confia em um user_id
/// enviado pelo client — o único jeito de "ser" um usuário é provar
/// posse de um token válido emitido pelo próprio Supabase Auth.
export async function requireAuth(request: FastifyRequest, reply: FastifyReply) {
  const authHeader = request.headers.authorization;

  if (!authHeader?.startsWith('Bearer ')) {
    return reply.code(401).send({ error: 'Token de autenticação ausente.' });
  }

  const token = authHeader.slice('Bearer '.length);
  const { data, error } = await supabaseAdmin.auth.getUser(token);

  if (error || !data.user) {
    return reply.code(401).send({ error: 'Token inválido ou expirado.' });
  }

  request.userId = data.user.id;
}
