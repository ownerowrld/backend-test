import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { requireAuth } from '../auth/require-auth.js';
import { supabaseAdmin } from '../plugins/supabase.js';

const assignBadgeSchema = z.object({
  username: z.string().min(1),
  badge_name: z.string().min(1),
});

async function checkIsAdmin(userId: string): Promise<boolean> {
  const { data } = await supabaseAdmin
    .from('admins')
    .select('user_id')
    .eq('user_id', userId)
    .maybeSingle();
  return !!data;
}

export async function badgesRoutes(app: FastifyInstance) {
  app.addHook('preHandler', requireAuth);

  // ---- GET /users/me/is-admin ----
  // Usado pelo app só pra decidir se mostra o link do painel de
  // gerenciamento — a permissão de verdade é sempre checada de novo
  // no backend em cada rota /admin/*, nunca confiada a partir daqui.
  app.get('/users/me/is-admin', async (request, reply) => {
    const isAdmin = await checkIsAdmin(request.userId!);
    return reply.send({ is_admin: isAdmin });
  });

  // ---- GET /users/me/badges ----
  app.get('/users/me/badges', async (request, reply) => {
    const { data, error } = await supabaseAdmin
      .from('user_badges')
      .select('*, badge:badges(*)')
      .eq('user_id', request.userId)
      .order('position');

    if (error) return reply.code(500).send({ error: 'Erro ao buscar badges.' });
    return reply.send(data);
  });

  // -----------------------------------------------------------
  // ADMIN — só quem está na tabela `admins` passa daqui.
  // A posse da badge "Founder" (visual) e a permissão administrativa
  // são coisas DIFERENTES e nunca são confundidas aqui.
  // -----------------------------------------------------------
  app.addHook('preHandler', async (request, reply) => {
    if (!request.url.startsWith('/admin/')) return;
    const isAdmin = await checkIsAdmin(request.userId!);
    if (!isAdmin) {
      return reply.code(403).send({ error: 'Acesso restrito a administradores.' });
    }
  });

  // ---- GET /admin/users/:username/badges ----
  // Lista as badges que um usuário específico já possui — usado
  // pelo BadgeManager pra mostrar o estado atual antes de atribuir.
  app.get<{ Params: { username: string } }>(
    '/admin/users/:username/badges',
    async (request, reply) => {
      const { username } = request.params;

      const { data: targetUser } = await supabaseAdmin
        .from('profiles')
        .select('user_id')
        .eq('username', username)
        .maybeSingle();

      if (!targetUser) return reply.code(404).send({ error: 'Usuário não encontrado.' });

      const { data, error } = await supabaseAdmin
        .from('user_badges')
        .select('*, badge:badges(*)')
        .eq('user_id', targetUser.user_id)
        .order('position');

      if (error) return reply.code(500).send({ error: 'Erro ao buscar badges.' });
      return reply.send(data);
    },
  );

  // ---- POST /admin/badges/assign ----
  app.post('/admin/badges/assign', async (request, reply) => {
    const parsed = assignBadgeSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: 'Dados inválidos.', details: parsed.error.format() });
    }
    const { username, badge_name } = parsed.data;

    const { data: targetUser } = await supabaseAdmin
      .from('profiles')
      .select('user_id')
      .eq('username', username)
      .maybeSingle();
    if (!targetUser) return reply.code(404).send({ error: 'Usuário não encontrado.' });

    const { data: badge } = await supabaseAdmin
      .from('badges')
      .select('id')
      .eq('name', badge_name)
      .maybeSingle();
    if (!badge) return reply.code(404).send({ error: 'Badge não encontrada.' });

    const { error } = await supabaseAdmin
      .from('user_badges')
      .upsert(
        { user_id: targetUser.user_id, badge_id: badge.id },
        { onConflict: 'user_id,badge_id', ignoreDuplicates: true },
      );

    if (error) return reply.code(500).send({ error: 'Erro ao atribuir badge.' });
    return reply.code(204).send();
  });

  // ---- DELETE /admin/badges/:userId ----
  app.delete<{ Params: { userId: string }; Body: { badge_name: string } }>(
    '/admin/badges/:userId',
    async (request, reply) => {
      const { userId } = request.params;
      const badgeName = z.string().min(1).parse((request.body as any)?.badge_name);

      const { data: badge } = await supabaseAdmin
        .from('badges')
        .select('id')
        .eq('name', badgeName)
        .maybeSingle();
      if (!badge) return reply.code(404).send({ error: 'Badge não encontrada.' });

      await supabaseAdmin
        .from('user_badges')
        .delete()
        .eq('user_id', userId)
        .eq('badge_id', badge.id);

      return reply.code(204).send();
    },
  );
}
