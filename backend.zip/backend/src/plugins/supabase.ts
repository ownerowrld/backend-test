import { createClient } from '@supabase/supabase-js';
import { env } from '../env.js';

/// Cliente Supabase com a service_role key — só existe no backend.
/// Bypassa RLS, então TODA validação de permissão precisa ser feita
/// aqui em código, nunca assumida.
export const supabaseAdmin = createClient(env.SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
});
