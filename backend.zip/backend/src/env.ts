import 'dotenv/config';
import { z } from 'zod';

/// Schema de validação das env vars — o processo nem sobe se faltar algo.
const envSchema = z.object({
  PORT: z.string().default('3333'),

  // Supabase — aqui SIM usamos a service_role key, porque este backend
  // precisa ignorar RLS pra gerenciar badges/admins. NUNCA exponha essa
  // chave pro client (Flutter).
  SUPABASE_URL: z.string().url(),
  SUPABASE_SERVICE_ROLE_KEY: z.string().min(1),

  // LiveKit — API Secret fica só aqui, nunca no app.
  LIVEKIT_API_KEY: z.string().min(1),
  LIVEKIT_API_SECRET: z.string().min(1),
  LIVEKIT_WS_URL: z.string().url(),

  // CORS — origem(ns) permitida(s) pra chamar este backend
  CORS_ORIGIN: z.string().default('*'),
});

const parsed = envSchema.safeParse(process.env);

if (!parsed.success) {
  console.error('❌ Variáveis de ambiente inválidas/faltando:');
  console.error(parsed.error.format());
  process.exit(1);
}

export const env = parsed.data;
